﻿using LibraryApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LibraryApp.Data
{
    public class Data
    {
        public static List<Book> Books = new List<Book> {
                new Book { Name = "Book1", Author = "Auhtor1", YearOfPublishing = 2000, Id = 0},
                new Book { Name = "Book2", Author = "Auhtor2", YearOfPublishing = 1965, Id = 1 },
                new Book { Name = "Book3", Author = "Auhtor2", YearOfPublishing = 1960, Id = 2 },
                new Book { Name = "Book4", Author = "Auhtor1", YearOfPublishing = 2010, Id = 3 },
                new Book { Name = "Book5", Author = "Auhtor3", YearOfPublishing = 1000, Id = 4 }
        };
        public static List<Client> Clients = new List<Client> {
                new Client { Name = "Jon Doe", Age=20, LibraryId=5, Id = 0},
                new Client { Name = "Jane Doe", Age=32, LibraryId=3, Id = 1},
                new Client { Name = "John Smith", Age=43, LibraryId=5, Id = 2},
                new Client { Name = "Peter Smith", Age=25, LibraryId=5, Id = 3},
                new Client { Name = "Jake Adams", Age=14, LibraryId=5, Id = 4},
                new Client { Name = "James Peterson", Age=40, LibraryId=5, Id = 5},
        };

        public static List<ClientsByBook> ClientsByBooks = new List<ClientsByBook> {
            new ClientsByBook{ Book = Books[0], Clients = new List<Client>{ Clients[0], Clients[1] } },
            new ClientsByBook{ Book = Books[1], Clients = new List<Client>{ Clients[2], Clients[3] } },
            new ClientsByBook{ Book = Books[2], Clients = new List<Client>{ Clients[1], Clients[4] , Clients[2]} },
            new ClientsByBook{ Book = Books[2], Clients = new List<Client>{ Clients[0], Clients[3] , Clients[5]} },
            new ClientsByBook{ Book = Books[2], Clients = new List<Client>{ Clients[5], Clients[2] , Clients[3]} },
        };



    }
}
